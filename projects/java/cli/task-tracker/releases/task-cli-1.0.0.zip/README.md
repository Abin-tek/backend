# task-cli — quick installer bundle

Requirements:
- java 8 or above

Files:
- task-cli.jar        — the fat jar (rename may differ)
- task-cli            — bash launcher (Linux/macOS/Git Bash/WSL)
- task-cli.bat        — cmd launcher (Windows)
- task-cli.ps1        — PowerShell launcher (Windows PowerShell)

Installation (recommended user-level):
- Linux/macOS/Git Bash (run these commands in current dir):
  - `mkdir -p $HOME/.local/task-cli
     cp task-cli task-cli.jar $HOME/.local/task-cli/
     chmod +x $HOME/.local/task-cli/task-cli
     echo 'export PATH="$HOME/.local/task-cli:$PATH"' >> ~/.bashrc
     source ~/.bashrc`

- Windows:
  - Extract to a folder (e.g. C:\Program Files\task-cli)
  - Add the folder to PATH (System or User PATH)
        
Usage:
- Run `task-cli --help` from any terminal.
