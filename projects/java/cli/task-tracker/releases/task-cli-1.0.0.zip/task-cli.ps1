param([Parameter(ValueFromRemainingArguments=$true)] $Args)
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
java -jar (Join-Path $scriptDir "task-cli.jar") @Args
